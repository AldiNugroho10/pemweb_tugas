<?php
require './../config/db.php';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $user = mysqli_query($db_connect, "SELECT * FROM users WHERE email = '$email'");

    if (mysqli_num_rows($user) > 0) {
        $data = mysqli_fetch_assoc($user);

        if (password_verify($password, $data['password'])) {
            // echo "selamat datang " . $data['name'];
            // die;
            session_start();

            // otorisasi
            $_SESSION['name'] = $data['name'];
            $_SESSION['role'] = $data['role'];

            if ($_SESSION['role'] == 'user') {
                header('Location: ./../profile.php');
                die; // Make sure to stop the script after redirecting
            } elseif ($_SESSION['role'] == 'admin') {
                header('Location: ./../admin.php');
                die; // Make sure to stop the script after redirecting
            } else {
                echo "Role tidak valid";
                die;
            }
        } else {
            echo "password salah";
            die;
        }
    } else {
        echo "email atau password salah";
        die;
    }
}
?>
